package com.example.financas_facil

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
